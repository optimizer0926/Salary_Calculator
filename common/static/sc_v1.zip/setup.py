from setuptools import setup

setup(name='django 1.7 on Red Hat Openshift',
    version='1.3',
    description='django on OpenShift',
    author='',
    author_email='',
    url='https://github.com/jfmatth/openshift-django17',
)
