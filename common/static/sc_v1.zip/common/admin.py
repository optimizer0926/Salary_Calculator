from django.contrib import admin

from common.models import Establishment

admin.site.register(Establishment)
