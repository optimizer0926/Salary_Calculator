from django.conf.urls import patterns, include, url
from django.contrib import admin

from personnel import views as personnel_views
from reports import views as report_views

urlpatterns = patterns('',
    url(r'^admin/', include(admin.site.urls)),

    # login/logout
    url(r'^accounts/login/$', 'django.contrib.auth.views.login', {'template_name': 'login.html'}, name='login'),
    url(r'^accounts/logout/$', 'django.contrib.auth.views.logout_then_login', name='logout'),

    # Personnel
    url(r'^$', personnel_views.DepartmentListView.as_view(), name='root'),

    url(r'^personnel/departments/$', personnel_views.DepartmentListView.as_view(), name='department-list'),
    url(r'^personnel/departments/create/$', personnel_views.DepartmentCreateView.as_view(), name='department-create'),
    url(r'^personnel/departments/(?P<pk>\d+)/$', personnel_views.DepartmentUpdateView.as_view(), name='department-update'),
    url(r'^personnel/departments/(?P<pk>\d+)/delete/$', personnel_views.DepartmentDeleteView.as_view(), name='department-delete'),

    url(r'^personnel/positions/$', personnel_views.PositionListView.as_view(), name='position-list'),
    url(r'^personnel/positions/create/$', personnel_views.PositionCreateView.as_view(), name='position-create'),
    url(r'^personnel/positions/(?P<pk>\d+)/$', personnel_views.PositionUpdateView.as_view(), name='position-update'),
    url(r'^personnel/positions/(?P<pk>\d+)/delete/$', personnel_views.PositionDeleteView.as_view(), name='position-delete'),

    url(r'^personnel/departments/(?P<department_id>\d+)/employees/$', personnel_views.EmployeeListView.as_view(), name='employee-list'),
    url(r'^personnel/departments/(?P<department_id>\d+)/employees/create/$', personnel_views.EmployeeCreateView.as_view(), name='employee-create'),
    url(r'^personnel/employees/(?P<pk>\d+)/$', personnel_views.EmployeeUpdateView.as_view(), name='employee-update'),
    url(r'^personnel/employees/(?P<pk>\d+)/delete/$', personnel_views.EmployeeDeleteView.as_view(), name='employee-delete'),

    url(r'^personnel/bonuses/$', personnel_views.BonusListView.as_view(), name='bonus-list'),
    url(r'^personnel/bonuses/create/$', personnel_views.BonusCreateView.as_view(), name='bonus-create'),
    url(r'^personnel/bonuses/(?P<pk>\d+)/$', personnel_views.BonusUpdateView.as_view(), name='bonus-update'),
    url(r'^personnel/bonuses/(?P<pk>\d+)/delete/$', personnel_views.BonusDeleteView.as_view(), name='bonus-delete'),

    url(r'^personnel/sicktimes/$', personnel_views.SickTimeListView.as_view(), name='sicktime-list'),
    url(r'^personnel/sicktimes/create/$', personnel_views.SickTimeCreateView.as_view(), name='sicktime-create'),
    url(r'^personnel/sicktimes/(?P<pk>\d+)/$', personnel_views.SickTimeUpdateView.as_view(), name='sicktime-update'),
    url(r'^personnel/sicktimes/(?P<pk>\d+)/delete/$', personnel_views.SickTimeDeleteView.as_view(), name='sicktime-delete'),

    url(r'^personnel/vacations/$', personnel_views.VacationListView.as_view(), name='vacation-list'),
    url(r'^personnel/vacations/create/$', personnel_views.VacationCreateView.as_view(), name='vacation-create'),
    url(r'^personnel/vacations/(?P<pk>\d+)/$', personnel_views.VacationUpdateView.as_view(), name='vacation-update'),
    url(r'^personnel/vacations/(?P<pk>\d+)/delete/$', personnel_views.VacationDeleteView.as_view(), name='vacation-delete'),

    # Reports
    url(r'^reports/$', report_views.ReportListView.as_view(), name='report-list'),
    url(r'^reports/summary/$', report_views.SummaryReportView.as_view(), name='report-summary'),
    url(r'^reports/sick/$', report_views.SickReportView.as_view(), name='report-sick'),
    url(r'^reports/vacation/$', report_views.VacationReportView.as_view(), name='report-vacation'),
    url(r'^reports/bonus/$', report_views.BonusReportView.as_view(), name='report-bonus'),
)
